#ifndef controller_H
  #define controller_H
  #include <Bluepad32.h>

 extern int16_t var_index;        // Controller Index
  extern int16_t var_dpad;         // D-pad
  extern int16_t var_buttons;      // bitmask of pressed buttons
  extern int16_t var_axisX;        // (-511 - 512) left X Axis
  extern int16_t var_axisY;        // (-511 - 512) left Y axis
  extern int16_t var_axisRX;      // (-511 - 512) right X axis
  extern int16_t var_axisRY;       // (-511 - 512) right Y axis
  extern int16_t var_brake;        // (0 - 1023): brake button
  extern int16_t var_throttle;     // (0 - 1023): throttle (AKA gas) button
  extern int16_t var_miscButtons;  // bitmask of pressed "misc" buttons
  extern int16_t var_gyroX;        // Gyro X
  extern int16_t var_gyroY;        // Gyro Y
  extern int16_t var_gyroZ;        // Gyro Z
  extern int16_t var_accelX;       // Accelerometer X
  extern int16_t var_accelY;       // Accelerometer Y
  extern int16_t var_accelZ;        // Accelerometer Z
 


  void onConnectedController(ControllerPtr); 
  void onDisconnectedController(ControllerPtr); 
  void dumpGamepad(ControllerPtr); 
  void dumpMouse(ControllerPtr); 
  void dumpKeyboard(ControllerPtr); 
  void dumpBalanceBoard(ControllerPtr);
  void processGamepad(ControllerPtr); 
  void processMouse(ControllerPtr); 
  void processKeyboard(ControllerPtr); 
  void processBalanceBoard(ControllerPtr);
  void processControllers(void); 
  void initBT_Controller(void);
  void controllerUpdate(void);
#endif//